import { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";

export interface AiGenerationStep {
  label: string;
  detail: string;
}

export const INITIAL_AI_GENERATION_STEPS: AiGenerationStep[] = [
  { label: "건강 데이터 요약 중", detail: "신체 정보와 이번 주 활동 기록을 정리하고 있어요." },
  { label: "공공 기준과 비교 중", detail: "BMI, 활동 흐름, 수면 데이터를 앱 기준과 맞춰보고 있어요." },
  { label: "개인화 정책 계산 중", detail: "목표와 최근 미션 반응을 반영해 적절한 범위를 고르고 있어요." },
  { label: "AI 미션 생성 중", detail: "정책 범위 안에서 미션과 추천 이유를 만들고 있어요." },
  { label: "서버 검수 중", detail: "미션 타입, 수치, 루틴 키, 금지 문구를 확인하고 있어요." },
  { label: "게임 화면에 반영 중", detail: "검수된 미션을 저장하고 화면에 불러오고 있어요." },
];

export const MISSION_REGENERATION_STEPS: AiGenerationStep[] = [
  { label: "기존 미션 확인 중", detail: "현재 슬롯과 직전 미션 정보를 확인하고 있어요." },
  { label: "행동 이력 반영 중", detail: "최근 완료와 새로고침 패턴을 다시 살펴보고 있어요." },
  { label: "개인화 정책 재계산 중", detail: "목표 수치와 루틴 후보를 다시 조정하고 있어요." },
  { label: "새 미션 생성 중", detail: "AI가 새 추천 이유와 미션 문구를 만들고 있어요." },
  { label: "서버 검수 중", detail: "중복, 수치, 루틴 반복 여부를 확인하고 있어요." },
  { label: "새 미션 반영 중", detail: "검수된 미션을 카드에 적용하고 있어요." },
];

export const MISSION_RETRY_STEPS: AiGenerationStep[] = [
  { label: "빈 슬롯 확인 중", detail: "생성이 필요한 미션 슬롯을 확인하고 있어요." },
  { label: "개인화 기준 적용 중", detail: "현재 건강 요약과 목표에 맞는 후보를 고르고 있어요." },
  { label: "AI 미션 생성 중", detail: "새로운 미션과 추천 이유를 만들고 있어요." },
  { label: "서버 검수 중", detail: "중복과 형식 오류를 확인하고 있어요." },
  { label: "미션 카드 반영 중", detail: "새 미션을 화면에 표시하고 있어요." },
];

export const MISSION_START_STEPS: AiGenerationStep[] = [
  { label: "미션 시작 준비 중", detail: "선택한 미션의 진행 상태를 확인하고 있어요." },
  { label: "진행 상태 저장 중", detail: "타이머와 체크 상태를 시작할 수 있게 바꾸고 있어요." },
  { label: "화면 반영 중", detail: "바로 진행할 수 있도록 미션 카드를 업데이트하고 있어요." },
];

export const MISSION_COMPLETE_STEPS: AiGenerationStep[] = [
  { label: "완료 조건 확인 중", detail: "걸음 수, 타이머, 루틴 체크, 기록 조건을 확인하고 있어요." },
  { label: "보상 계산 중", detail: "EXP와 코인 보상을 반영하고 있어요." },
  { label: "다음 미션 준비 중", detail: "완료 이력을 반영해 새 미션 후보를 조정하고 있어요." },
  { label: "AI 미션 생성 중", detail: "다음 미션과 추천 이유를 만들고 있어요." },
  { label: "서버 검수 중", detail: "새 미션이 규칙에 맞는지 확인하고 있어요." },
  { label: "게임 화면 반영 중", detail: "보상과 새 미션을 화면에 적용하고 있어요." },
];

interface AiGenerationStepTickerProps {
  active?: boolean;
  steps?: AiGenerationStep[];
  title?: string;
  className?: string;
  intervalMs?: number;
  compact?: boolean;
  showCounter?: boolean;
  currentStep?: AiGenerationStep | null;
  progressPercent?: number | null;
  currentStepIndex?: number | null;
  totalSteps?: number | null;
}

const AiGenerationStepTicker = ({
  active = true,
  steps = INITIAL_AI_GENERATION_STEPS,
  title = "AI 미션 처리 중",
  className = "",
  intervalMs = 1200,
  compact = false,
  showCounter = true,
  currentStep = null,
  progressPercent = null,
  currentStepIndex = null,
  totalSteps = null,
}: AiGenerationStepTickerProps) => {
  const safeSteps = useMemo(
    () => (steps.length > 0 ? steps : INITIAL_AI_GENERATION_STEPS),
    [steps],
  );
  const [stepIndex, setStepIndex] = useState(0);

  useEffect(() => {
    if (currentStep) {
      return;
    }

    if (!active) {
      setStepIndex(0);
      return;
    }

    setStepIndex(0);
    const timer = window.setInterval(() => {
      setStepIndex((prev) => (prev + 1) % safeSteps.length);
    }, intervalMs);

    return () => window.clearInterval(timer);
  }, [active, intervalMs, safeSteps.length, currentStep]);

  const resolvedStep = currentStep ?? safeSteps[stepIndex] ?? safeSteps[0];
  const resolvedStepIndex = currentStepIndex ?? stepIndex + 1;
  const resolvedTotalSteps = totalSteps ?? safeSteps.length;
  const resolvedProgress = typeof progressPercent === 'number'
    ? Math.max(0, Math.min(100, progressPercent))
    : null;

  return (
    <div
      className={`rounded-2xl border border-violet-300/15 bg-black/25 backdrop-blur-sm ${
        compact ? "px-3 py-2.5" : "p-3"
      } ${className}`}
    >
      <div className="flex items-center justify-between gap-3">
        <p className="text-[10px] font-black tracking-[0.16em] text-violet-100/70 uppercase">
          {title}
        </p>
        {showCounter && (
          <p className="text-[10px] font-bold text-white/35">
            {resolvedStepIndex}/{resolvedTotalSteps}
          </p>
        )}
      </div>

      <div className={compact ? "mt-1.5 min-h-[42px]" : "mt-2 min-h-[52px]"}>
        <AnimatePresence mode="wait">
          <motion.div
            key={`${resolvedStep.label}-${resolvedStepIndex}`}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.22 }}
          >
            <p className={compact ? "text-sm font-black text-white" : "text-[13px] font-black text-white"}>
              {resolvedStep.label}
            </p>
            <p className={compact ? "mt-0.5 text-[11px] leading-snug text-white/55" : "mt-1 text-[11px] leading-relaxed text-white/55"}>
              {resolvedStep.detail}
            </p>
          </motion.div>
        </AnimatePresence>
      </div>

      {resolvedProgress !== null ? (
        <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/12">
          <motion.div
            className="h-full rounded-full bg-violet-300/90"
            initial={false}
            animate={{ width: `${resolvedProgress}%` }}
            transition={{ duration: 0.25 }}
          />
        </div>
      ) : (
        <div className="mt-2 flex items-center gap-1">
          {safeSteps.map((step, index) => (
            <span
              key={`${step.label}-dot`}
              className={`h-1 flex-1 rounded-full transition-all duration-300 ${
                index === stepIndex ? "bg-violet-300/90" : "bg-white/12"
              }`}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default AiGenerationStepTicker;
